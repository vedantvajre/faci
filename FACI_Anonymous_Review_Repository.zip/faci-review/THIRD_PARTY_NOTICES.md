# Third-party material

The token-site study uses counterfactually augmented NLI data from Kaushik, Hovy, and Lipton, *Learning the Difference that Makes a Difference with Counterfactually-Augmented Data* (ICLR 2020):

https://github.com/acmi-lab/counterfactually-augmented-data

Pinned commit: `6f232a1d2a11462a30ce08fb4825b734ab30828e`. The original repository README and LICENSE are preserved in `results/token_sites/data/source/`. See the source manifest for the exact files. SNLI attribution and its CC BY-SA 4.0 terms also apply to underlying SNLI material; the repository license does not replace dataset-specific terms.

The experiments refer to public Hugging Face datasets and model checkpoints. Their identifiers, revisions, and source citations are retained as scientific provenance. Model weights are downloaded by the notebooks and are not redistributed in this snapshot. Each external dataset/checkpoint remains subject to its own terms.

No new blanket open-source license is asserted for the FACI code in this review snapshot. Existing third-party license notices remain effective. A public release license requires a separate author decision.
