# Reproduction and inspection

## Inspect completed results first

No model run is needed to read the saved results. Start with:

- `results/nli_correction/summary/corrected_conditions.csv` and `per_seed.csv`;
- `results/token_sites/analysis/model_summary.csv` and `layer_site_summary.csv`;
- `results/token_sites/analysis/analysis_summary.json` and `pair_contrasts.csv`;
- raw pair records, calibration and endpoint checks in the same experiment directories.

## Replot the token-site figure (CPU only)

Use Python with pandas and Matplotlib. The requirements below match the environment used to prepare and verify the paper-layout figure:

```bash
python -m pip install -r requirements-figure.txt
python scripts/plot_token_sites.py
```

The script reads the saved layer statistics and writes `reproduced/fig_token_sites.pdf` and a PNG preview. It changes no measurement or statistic. The submitted figure is also provided in `figures/`. Font availability may change appearance slightly; the script's fallback list is explicit. PDF timestamps may differ between runs.

## Reproduce the token-site measurements in Colab

1. Upload `notebooks/FACI_Token_Sites_v1.ipynb` to Colab.
2. Select a GPU runtime. The recorded run used a Tesla T4; exact runtime details are in `results/token_sites/environment.json`.
3. Run numbered Cell 1, restart the runtime, then start at numbered Cell 2. Do not immediately use Run all across the required restart.
4. Authorize your own Drive when prompted. Use a Drive without an existing `FACI_Token_Sites_v1` output directory to start a fresh run. The notebook guards the frozen protocol and runtime on resume.
5. Continue through Cells 3–12 in order. Cell 9 runs BERT, Cell 10 runs RoBERTa, Cell 11 analyzes, and Cell 12 exports the archive.

The source commit, checkpoint revisions, label maps, cohort selection, estimators, and bootstrap seed are recorded in the notebook and result bundle. The notebook downloads third-party data/checkpoints; network access is required. The 100 matched pairs are not selected using model accuracy or recovery outcomes.

## Reproduce the bounded NLI correction in Colab

1. Upload `notebooks/FACI_NLI_Correction_v1.ipynb` to Colab and select a GPU runtime.
2. Run the first installation code cell; restart the runtime before the setup/import cell.
3. Run the subsequent code cells sequentially in a fresh run. Use your own Drive without an existing `FACI_NLI_correction_v1` directory; an existing run is checked rather than silently overwritten.
4. When setup requests a supplementary ZIP, upload **`results/nli_correction/source_original.zip`**. The prompt names an earlier filename, but the code validates the bytes rather than the filename. The expected SHA-256 is `83758518e9c814f7d03182e082abd514ea417d4e3bd8b1d0eabc7fc091b7d9b5`.
5. Continue through calibration, classifier runs, pretrained auxiliary runs, and the summary/export cell. The final original cell containing `0` has no experimental role.

This source ZIP is retained byte-for-byte because the correction notebook verifies it. The notebook's compatibility shim and bounded fixes are part of its original code. Saved notebook-cell sources also appear in `results/nli_correction/notebook_cells/`.

## Historical material

`historical/code/` contains the earlier framework and runners; `historical/results/` contains its archived outputs. Its original reproduction command has not been certified for this release. In particular, that package refers to a missing `mechinterp.baselines` module; the correction notebook contains a bounded import compatibility shim. The historical README's claims of complete reproducibility and per-layer medians should not be treated as validation of the older records. Consult `results/nli_correction/remaining_manuscript_dependencies.json` for the recorded profile limitations.

`archive/precision_stability/FACI_Experiment.ipynb` is a separate exploratory notebook, not the historical benchmark runner. It uses earlier source/result inputs and is retained for provenance, not offered as a validated end-to-end reproduction of a paper claim.
