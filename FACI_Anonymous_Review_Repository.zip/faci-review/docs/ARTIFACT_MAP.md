# Artifact map

| Experiment or output | Inputs and implementation | Saved evidence |
| --- | --- | --- |
| Historical benchmark and controls | `historical/code/src/`, `historical/code/scripts/`, `historical/code/configs/` | `historical/results/`; historical version, not regenerated for this snapshot |
| Bounded BERT/RoBERTa NLI correction | `notebooks/FACI_NLI_Correction_v1.ipynb`, exact `results/nli_correction/source_original.zip` | `results/nli_correction/runs/`, `checks/`, `calibration/`, `summary/`, `auxiliary/` |
| Token-site comparison | `notebooks/FACI_Token_Sites_v1.ipynb`, `results/token_sites/protocol.json`, `data/cohort.json`, `models/` | `results/token_sites/raw/`, `checks/`, `analysis/` |
| Token-site figure in the paper | `scripts/plot_token_sites.py`, saved `layer_site_summary.csv` | `figures/fig_token_sites.pdf` |
| Exploratory precision experiment | `archive/precision_stability/FACI_Experiment.ipynb` | Archived code only; not a positive filtering-reliability result |

For the token-site experiment, `data/source_manifest.json` pins the source repository commit and file hashes; `data/selected_pairs.csv` identifies the frozen contrasts. `analysis/patch_outcomes.csv` exposes individual patches and `analysis/bootstrap_contrast_estimates.npz` retains the bootstrap draws. The saved figure within the raw experiment export uses the experiment's plotting layout; `figures/fig_token_sites.pdf` is the paper layout of the same layer statistics.

Files named `candidate_32_scalar_conditions.csv` and `candidate_pooled_correlation.json` are provisional combinations of corrected NLI and historical conditions. Their presence does not turn them into additional validated measurements. Preserved export manifests refer to their original experiment bundles; the root `MANIFEST.sha256` covers this assembled snapshot.
