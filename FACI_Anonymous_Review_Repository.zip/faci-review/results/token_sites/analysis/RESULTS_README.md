# FACI token-site experiment: frozen analysis

This is a new diagnostic experiment. It does not replace, rerun, or repair the historical FACI benchmark.

The primary estimate is the median across valid pairs of each pair's mean (edited-token recovery minus read-out-token recovery) across the first six transformer blocks. A positive estimate means the edited-token patch transfers more of the measured contrast within this prespecified early window. It does not locate a unique representation, prove necessity, or establish when an entire model first computes an answer.

All intervals are per-model percentile 95% source-group bootstrap intervals. Curve bands are pointwise, not simultaneous. There are no per-layer p-values. Curves are median-over-pairs for this new dataset, not the historical ten-seed profile aggregation. Recovery is signed and unbounded; no clipping or correctness filtering is applied.

## bert_nli

Admitted pairs: 100; gap-valid pairs: 100; valid source groups: 100; VPR: 1.000.
Primary interpretation gate: True. Passes prespecified size/applicability checks; evaluate estimate and limitations
Primary median edited-minus-read-out contrast: 0.962185; 95% CI: [0.9501846127235113, 0.975423536441311].
Secondary median edited-minus-control contrast: 0.965623; 95% CI: [0.9524032807527176, 0.9807223463786332].
Raw margin primary contrast (descriptive median): 10.1259.
Architectural endpoint check passed: True.

## roberta_nli

Admitted pairs: 100; gap-valid pairs: 100; valid source groups: 100; VPR: 1.000.
Primary interpretation gate: True. Passes prespecified size/applicability checks; evaluate estimate and limitations
Primary median edited-minus-read-out contrast: 0.931687; 95% CI: [0.9221897887321108, 0.9500767084242823].
Secondary median edited-minus-control contrast: 0.927618; 95% CI: [0.9194637931969897, 0.9480472479582991].
Raw margin primary contrast (descriptive median): 12.4811.
Architectural endpoint check passed: True.

## Interpretation limits

Final-block read-out recovery is forced by the intervention architecture; final-block edited/control recovery is zero because the classifier does not read those positions after the final block. These are implementation checks, not discoveries. The first six blocks are the prespecified primary window.

Larger effects at a token may partly reflect larger activation displacement. Inspect the patch-norm diagnostic; this experiment holds the number of patched vectors fixed, not their L2 displacement. The unchanged token is a comparison location, not a guaranteed null. Negative gaps and errors remain in the primary sample if gap-valid; correctness strata are descriptive only.

Do not select an earlier/later block window, change gamma, drop difficult examples, switch the curve estimator, or regenerate examples based on these outcomes. An uncertain or null result remains a valid result; a failed gate means the evidence is insufficient for the planned empirical claim.
