# FACI - Supplementary Material

One merged codebase; every protocol fix is baked into the source and verified in-package.

## Reproduce everything
pip install torch transformers "datasets>=4.0.0" scikit-learn scipy pyyaml
PYTHONPATH=code/src python code/scripts/run_multiseed.py --config code/configs/full8.yaml \
  --seeds 42 123 456 789 1000 2024 3141 5555 7777 9999 --output-dir results/rerun
Single commodity GPU, ~37 min/seed for all 32 conditions, three tiers.

## Layout
- code/src/mechinterp/   framework (architectures, tiers, tasks, output functions)
- code/scripts/          runners; held-out Tier-1 (200-perm null); nested grouped Tier-2;
                         controls; gamma ablation
- code/configs/full8.yaml   the full 8x4x3 configuration
- results/canonical/     per-seed + aggregated results (the paper's numbers)
- results/controls, gap_ablation, grouping_ablation   produced with THIS code
- results/auxiliary_pretrained_nli_tier1.json   pretrained BERT/RoBERTa NLI Tier-1 (0.53/0.50)

## Protocol provenance
- Tier-3: single read-out-position residual patch, isinstance-dispatched; every record carries
  tier3_intervention = "readout-pos-v3-taskfix" and per-layer medians (tier3_layer_recoveries).
- Pairs: positives and negatives drawn with the SAME per-condition seed; factual = 14 curated
  facts with formatted subjects, index-aligned object-swap negatives; QA = same-context
  wrong-answer pairs. Construction is assertion-checked (see VERIFICATION.md).
- Fine-tuned encoder checkpoints (textattack SST-2/MNLI) with verified label indices;
  per-record "checkpoint" field.
- Completion tasks are constructionally trivial under this intervention (paper Sec. 4.4);
  their Tier-3 cells are flagged CT, not interpreted.
