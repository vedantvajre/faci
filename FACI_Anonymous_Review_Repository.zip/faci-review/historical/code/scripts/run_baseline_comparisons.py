#!/usr/bin/env python
"""
Baseline Comparison Suite for MechInterp Framework

Runs all three tier comparisons against baselines to validate the methodology.
Integrates with existing mechinterp framework structure.

Usage:
    python scripts/run_baseline_comparisons.py --models bert-base-uncased gpt2 --tasks sentiment nli
"""

import argparse
import json
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict
import warnings
warnings.filterwarnings("ignore")

import torch
from sklearn.decomposition import PCA
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from scipy.stats import spearmanr, kendalltau


def convert_to_serializable(obj):
    """Convert numpy types to Python native types for JSON serialization."""
    if isinstance(obj, dict):
        return {k: convert_to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_to_serializable(v) for v in obj]
    elif isinstance(obj, (np.integer, np.int64, np.int32)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float64, np.float32)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, set):
        return list(obj)
    else:
        return obj


# ============================================================================
# TIER-1 BASELINE COMPARISON
# ============================================================================

def tier1_comparison(
    positive_activations: np.ndarray,
    negative_activations: np.ndarray,
    n_random_trials: int = 100
) -> Dict:
    """
    Compare mean-difference direction against baselines.
    
    Baselines:
    1. Random directions (expected AUC ≈ 0.5)
    2. PCA principal components (unsupervised)
    3. SVM (optimal linear separator - upper bound)
    """
    # Combine data
    X = np.vstack([positive_activations, negative_activations])
    y = np.array([1] * len(positive_activations) + [0] * len(negative_activations))
    dim = X.shape[1]
    
    # === Our Method: Mean Difference Direction ===
    pos_mean = positive_activations.mean(axis=0)
    neg_mean = negative_activations.mean(axis=0)
    mean_diff = pos_mean - neg_mean
    mean_diff_dir = mean_diff / (np.linalg.norm(mean_diff) + 1e-8)
    
    projections = X @ mean_diff_dir
    mean_diff_auc = roc_auc_score(y, projections)
    
    # === Baseline 1: Random Directions ===
    random_aucs = []
    for _ in range(n_random_trials):
        rand_dir = np.random.randn(dim)
        rand_dir = rand_dir / np.linalg.norm(rand_dir)
        proj = X @ rand_dir
        auc = roc_auc_score(y, proj)
        random_aucs.append(max(auc, 1 - auc))  # Handle flipped directions
    
    # === Baseline 2: PCA ===
    pca = PCA(n_components=min(5, dim, len(X) - 1))
    pca.fit(X)
    
    pca_aucs = []
    for i in range(min(3, pca.n_components_)):
        proj = X @ pca.components_[i]
        auc = roc_auc_score(y, proj)
        pca_aucs.append(max(auc, 1 - auc))
    while len(pca_aucs) < 3:
        pca_aucs.append(0.5)
    
    # === Baseline 3: SVM (Optimal) ===
    try:
        svm = LinearSVC(C=1.0, max_iter=5000, dual=False)
        svm.fit(X, y)
        svm_dir = svm.coef_[0] / (np.linalg.norm(svm.coef_[0]) + 1e-8)
        svm_auc = roc_auc_score(y, X @ svm_dir)
    except:
        svm_auc = mean_diff_auc
    
    return {
        "mean_diff_auc": float(mean_diff_auc),
        "random_auc_mean": float(np.mean(random_aucs)),
        "random_auc_std": float(np.std(random_aucs)),
        "pca_pc1_auc": float(pca_aucs[0]),
        "pca_pc2_auc": float(pca_aucs[1]),
        "pca_pc3_auc": float(pca_aucs[2]),
        "svm_auc": float(svm_auc),
        "improvement_over_random": float(mean_diff_auc - np.mean(random_aucs)),
        "improvement_over_pca": float(mean_diff_auc - max(pca_aucs)),
        "gap_to_optimal": float(svm_auc - mean_diff_auc),
    }


# ============================================================================
# TIER-2 BASELINE COMPARISON
# ============================================================================

def tier2_comparison(
    activations: np.ndarray,
    labels: np.ndarray,
    n_folds: int = 5
) -> Dict:
    """
    Compare linear probing against baselines.
    
    Baselines:
    1. Majority class (no learning)
    2. Random features (probe capacity)
    3. MLP probe (nonlinear - tests if info is truly linear)
    """
    X = activations
    y = labels
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    
    # === Baseline 1: Majority Class ===
    majority_acc = max(np.mean(y == 0), np.mean(y == 1))
    
    # === Our Method: Linear Probe ===
    linear_probe = LogisticRegression(C=1.0, max_iter=1000, random_state=42)
    linear_scores = cross_val_score(linear_probe, X_scaled, y, cv=cv, scoring='accuracy')
    linear_acc = linear_scores.mean()
    linear_std = linear_scores.std()
    
    # === Baseline 2: Random Features ===
    dim = X.shape[1]
    random_accs = []
    for _ in range(10):
        rand_proj = np.random.randn(dim, dim)
        rand_proj = rand_proj / np.linalg.norm(rand_proj, axis=0, keepdims=True)
        X_rand = X_scaled @ rand_proj
        probe = LogisticRegression(C=1.0, max_iter=1000, random_state=42)
        scores = cross_val_score(probe, X_rand, y, cv=cv, scoring='accuracy')
        random_accs.append(scores.mean())
    
    # === Baseline 3: MLP Probe ===
    mlp = MLPClassifier(hidden_layer_sizes=(256, 128), max_iter=1000, 
                        random_state=42, early_stopping=True)
    mlp_scores = cross_val_score(mlp, X_scaled, y, cv=cv, scoring='accuracy')
    mlp_acc = mlp_scores.mean()
    mlp_std = mlp_scores.std()
    
    return {
        "linear_acc": float(linear_acc),
        "linear_std": float(linear_std),
        "majority_acc": float(majority_acc),
        "random_acc_mean": float(np.mean(random_accs)),
        "random_acc_std": float(np.std(random_accs)),
        "mlp_acc": float(mlp_acc),
        "mlp_std": float(mlp_std),
        "improvement_over_majority": float(linear_acc - majority_acc),
        "improvement_over_random": float(linear_acc - np.mean(random_accs)),
        "linear_vs_mlp_gap": float(linear_acc - mlp_acc),
    }


# ============================================================================
# TIER-3 BASELINE COMPARISON
# ============================================================================

def compute_attention_importance(model, inputs, device="cpu") -> np.ndarray:
    """Compute layer-wise attention importance."""
    model.eval()
    
    try:
        with torch.no_grad():
            outputs = model(**{k: v.to(device) for k, v in inputs.items()}, 
                           output_attentions=True)
        
        # Check for attentions in different places depending on model type
        attentions = None
        if hasattr(outputs, 'attentions') and outputs.attentions is not None:
            attentions = outputs.attentions
        elif hasattr(outputs, 'encoder_attentions') and outputs.encoder_attentions is not None:
            attentions = outputs.encoder_attentions
        
        if attentions is None or len(attentions) == 0:
            # Return zeros if no attention available
            n_layers = 12  # Default
            if hasattr(model.config, 'num_hidden_layers'):
                n_layers = model.config.num_hidden_layers
            elif hasattr(model.config, 'n_layer'):
                n_layers = model.config.n_layer
            return np.zeros(n_layers)
        
        importance = []
        for layer_attn in attentions:
            if layer_attn is not None:
                # Average attention weight magnitude
                attn = layer_attn[0].mean().item()
                importance.append(attn)
            else:
                importance.append(0.0)
        
        return np.array(importance)
    except Exception as e:
        print(f"        Attention extraction error: {e}")
        return np.zeros(12)


def compute_gradient_importance(model, inputs, device="cpu") -> np.ndarray:
    """Compute layer-wise gradient importance."""
    model.eval()
    
    try:
        # Get layers based on model architecture
        layers = None
        if hasattr(model, 'bert') and hasattr(model.bert, 'encoder'):
            layers = model.bert.encoder.layer
        elif hasattr(model, 'roberta') and hasattr(model.roberta, 'encoder'):
            layers = model.roberta.encoder.layer
        elif hasattr(model, 'transformer') and hasattr(model.transformer, 'h'):
            layers = model.transformer.h
        elif hasattr(model, 'encoder') and hasattr(model.encoder, 'block'):
            layers = model.encoder.block
        elif hasattr(model, 'encoder') and hasattr(model.encoder, 'layer'):
            layers = model.encoder.layer
        elif hasattr(model, 'model') and hasattr(model.model, 'layers'):
            layers = model.model.layers
        
        if layers is None:
            return np.zeros(12)
        
        n_layers = len(layers)
        
        # Hook to capture gradients
        gradients = {}
        
        def save_grad(name):
            def hook(module, grad_input, grad_output):
                if grad_output is not None and grad_output[0] is not None:
                    gradients[name] = grad_output[0].detach().norm().item()
            return hook
        
        hooks = []
        for i, layer in enumerate(layers):
            hooks.append(layer.register_full_backward_hook(save_grad(f"layer_{i}")))
        
        # Forward and backward
        model.zero_grad()
        inputs_device = {k: v.to(device) for k, v in inputs.items()}
        
        outputs = model(**inputs_device)
        if hasattr(outputs, 'logits'):
            loss = outputs.logits.mean()
        elif hasattr(outputs, 'last_hidden_state'):
            loss = outputs.last_hidden_state.mean()
        else:
            loss = outputs[0].mean()
        
        loss.backward()
        
        # Remove hooks
        for hook in hooks:
            hook.remove()
        
        importance = [gradients.get(f"layer_{i}", 0.0) for i in range(n_layers)]
        return np.array(importance)
    
    except Exception as e:
        print(f"        Gradient extraction error: {e}")
        return np.zeros(12)


def tier3_comparison(
    tier3_recovery: np.ndarray,
    attention_importance: np.ndarray,
    gradient_importance: np.ndarray,
    top_k: int = 3
) -> Dict:
    """
    Compare Tier-3 causal recovery against observational methods.
    """
    # Align lengths
    min_len = min(
        len(tier3_recovery), 
        len(attention_importance) if len(attention_importance) > 0 else len(tier3_recovery),
        len(gradient_importance) if len(gradient_importance) > 0 else len(tier3_recovery)
    )
    
    if min_len == 0:
        return {
            "attention_spearman": 0.0,
            "gradient_spearman": 0.0,
            "attention_jaccard_top3": 0.0,
            "gradient_jaccard_top3": 0.0,
            "tier3_top_layers": [],
            "attention_top_layers": [],
            "gradient_top_layers": [],
            "error": "No valid data for comparison"
        }
    
    tier3 = tier3_recovery[:min_len]
    attn = attention_importance[:min_len] if len(attention_importance) >= min_len else np.zeros(min_len)
    grad = gradient_importance[:min_len] if len(gradient_importance) >= min_len else np.zeros(min_len)
    
    # Spearman correlations
    attn_rho = spearmanr(tier3, attn)[0] if np.std(attn) > 0 else 0.0
    grad_rho = spearmanr(tier3, grad)[0] if np.std(grad) > 0 else 0.0
    
    # Handle NaN
    attn_rho = 0.0 if np.isnan(attn_rho) else attn_rho
    grad_rho = 0.0 if np.isnan(grad_rho) else grad_rho
    
    # Jaccard for top-k
    tier3_topk = set(np.argsort(np.abs(tier3))[-top_k:].tolist())
    attn_topk = set(np.argsort(attn)[-top_k:].tolist()) if np.std(attn) > 0 else set()
    grad_topk = set(np.argsort(grad)[-top_k:].tolist()) if np.std(grad) > 0 else set()
    
    attn_jaccard = len(tier3_topk & attn_topk) / len(tier3_topk | attn_topk) if (tier3_topk | attn_topk) else 0.0
    grad_jaccard = len(tier3_topk & grad_topk) / len(tier3_topk | grad_topk) if (tier3_topk | grad_topk) else 0.0
    
    return {
        "attention_spearman": float(attn_rho),
        "gradient_spearman": float(grad_rho),
        "attention_jaccard_top3": float(attn_jaccard),
        "gradient_jaccard_top3": float(grad_jaccard),
        "tier3_top_layers": sorted(list(tier3_topk)),
        "attention_top_layers": sorted(list(attn_topk)),
        "gradient_top_layers": sorted(list(grad_topk)),
    }


# ============================================================================
# MAIN RUNNER - INTEGRATES WITH MECHINTERP FRAMEWORK
# ============================================================================

def run_comparisons(
    models: List[str],
    tasks: List[str],
    num_examples: int = 50,
    output_dir: Path = Path("results/baselines"),
    device: str = None
):
    """
    Run all baseline comparisons using the mechinterp framework.
    """
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
    
    print(f"Running baseline comparisons on {device}")
    print(f"Models: {models}")
    print(f"Tasks: {tasks}")
    
    # Try to import mechinterp framework
    try:
        from mechinterp.core.registry import get_model_wrapper, get_task
        from mechinterp.analyzers.tier1 import Tier1Analyzer
        from mechinterp.analyzers.tier2 import Tier2Analyzer
        from mechinterp.analyzers.tier3 import Tier3Analyzer
        USE_FRAMEWORK = True
        print("Using mechinterp framework")
    except ImportError:
        USE_FRAMEWORK = False
        print("mechinterp framework not found - using transformers directly")
    
    from transformers import AutoModel, AutoTokenizer
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    all_results = {
        "tier1": [],
        "tier2": [],
        "tier3": [],
    }
    
    for model_name in models:
        print(f"\n{'='*60}")
        print(f"Model: {model_name}")
        print('='*60)
        
        try:
            # Load model with eager attention to avoid SDPA issues
            model = AutoModel.from_pretrained(
                model_name, 
                attn_implementation="eager",
                trust_remote_code=True
            ).to(device)
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            model.eval()
        except Exception as e:
            print(f"  Error loading {model_name}: {e}")
            # Try without attn_implementation for older models
            try:
                model = AutoModel.from_pretrained(model_name, trust_remote_code=True).to(device)
                tokenizer = AutoTokenizer.from_pretrained(model_name)
                if tokenizer.pad_token is None:
                    tokenizer.pad_token = tokenizer.eos_token
                model.eval()
            except Exception as e2:
                print(f"  Failed to load {model_name}: {e2}")
                continue
        
        for task_name in tasks:
            print(f"\n  Task: {task_name}")
            
            # Get task data
            if USE_FRAMEWORK:
                try:
                    task = get_task(task_name)
                    pos_texts = task.get_positive_examples(num_examples)
                    neg_texts = task.get_negative_examples(num_examples)
                except Exception as e:
                    print(f"    Using fallback examples (framework error: {e})")
                    pos_texts, neg_texts = get_fallback_examples(task_name, num_examples)
            else:
                pos_texts, neg_texts = get_fallback_examples(task_name, num_examples)
            
            # === TIER-1 COMPARISON ===
            print("    Running Tier-1 comparison...")
            try:
                pos_acts, neg_acts = extract_activations(
                    model, tokenizer, pos_texts, neg_texts, num_examples, device
                )
                
                tier1_result = tier1_comparison(pos_acts, neg_acts)
                tier1_result["model"] = model_name
                tier1_result["task"] = task_name
                all_results["tier1"].append(tier1_result)
                
                print(f"      Ours: {tier1_result['mean_diff_auc']:.3f}, "
                      f"Random: {tier1_result['random_auc_mean']:.3f}, "
                      f"PCA: {tier1_result['pca_pc1_auc']:.3f}, "
                      f"SVM: {tier1_result['svm_auc']:.3f}")
            except Exception as e:
                print(f"      Tier-1 error: {e}")
                pos_acts, neg_acts = None, None
            
            # === TIER-2 COMPARISON ===
            print("    Running Tier-2 comparison...")
            try:
                if pos_acts is not None and neg_acts is not None:
                    all_acts = np.vstack([pos_acts, neg_acts])
                    all_labels = np.array([1] * len(pos_acts) + [0] * len(neg_acts))
                    
                    tier2_result = tier2_comparison(all_acts, all_labels)
                    tier2_result["model"] = model_name
                    tier2_result["task"] = task_name
                    all_results["tier2"].append(tier2_result)
                    
                    print(f"      Linear: {tier2_result['linear_acc']:.3f}, "
                          f"Majority: {tier2_result['majority_acc']:.3f}, "
                          f"MLP: {tier2_result['mlp_acc']:.3f}")
                else:
                    print("      Skipped (no activations)")
            except Exception as e:
                print(f"      Tier-2 error: {e}")
            
            # === TIER-3 COMPARISON ===
            print("    Running Tier-3 comparison...")
            try:
                sample_text = pos_texts[0] if pos_texts else "Sample text"
                inputs = tokenizer(sample_text, return_tensors="pt", truncation=True, max_length=128)
                
                attn_imp = compute_attention_importance(model, inputs, device)
                grad_imp = compute_gradient_importance(model, inputs, device)
                
                # Get number of layers for placeholder
                n_layers = len(attn_imp) if len(attn_imp) > 0 else 12
                # Placeholder - replace with actual Tier-3 results
                tier3_recovery = np.random.rand(n_layers)  
                
                tier3_result = tier3_comparison(tier3_recovery, attn_imp, grad_imp)
                tier3_result["model"] = model_name
                tier3_result["task"] = task_name
                tier3_result["note"] = "Using placeholder Tier-3 recovery - replace with actual results"
                all_results["tier3"].append(tier3_result)
                
                print(f"      Attn ρ: {tier3_result['attention_spearman']:.3f}, "
                      f"Grad ρ: {tier3_result['gradient_spearman']:.3f}")
            except Exception as e:
                print(f"      Tier-3 error: {e}")
        
        # Free memory
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    # Save results with proper serialization
    for tier_name, results in all_results.items():
        if results:
            output_path = output_dir / f"{tier_name}_comparison.json"
            serializable_results = convert_to_serializable(results)
            with open(output_path, "w") as f:
                json.dump(serializable_results, f, indent=2)
            print(f"\nSaved {tier_name} results to {output_path}")
    
    # Print summary tables
    print_summary(all_results)
    
    return all_results


def get_fallback_examples(task_name: str, num_examples: int) -> Tuple[List[str], List[str]]:
    """Get fallback examples when framework is not available."""
    if task_name == "sentiment":
        pos_base = [
            "This movie was absolutely wonderful and I loved every moment of it.",
            "An excellent film with outstanding performances.",
            "I really enjoyed this, highly recommended!",
            "Fantastic experience, would definitely watch again.",
            "This is one of the best movies I've ever seen.",
        ]
        neg_base = [
            "This movie was terrible and I hated every minute of it.",
            "A dreadful film with awful performances.",
            "I really disliked this, do not recommend.",
            "Horrible experience, would never watch again.",
            "This is one of the worst movies I've ever seen.",
        ]
    elif task_name == "nli":
        pos_base = [
            "A man is playing guitar. A person is making music.",
            "The dog is running in the park. An animal is moving outside.",
            "She is cooking dinner. Someone is preparing food.",
            "The children are laughing. Young people are happy.",
            "He is reading a book. A person is looking at text.",
        ]
        neg_base = [
            "A man is playing guitar. Nobody is making any sound.",
            "The dog is running in the park. No animals are outside.",
            "She is cooking dinner. The kitchen is empty.",
            "The children are laughing. Everyone is crying.",
            "He is reading a book. No one can see anything.",
        ]
    elif task_name == "factual_recall":
        pos_base = [
            "The capital of France is Paris.",
            "The largest planet in our solar system is Jupiter.",
            "Water freezes at 0 degrees Celsius.",
            "The speed of light is approximately 300,000 km/s.",
            "Mount Everest is the tallest mountain on Earth.",
        ]
        neg_base = [
            "The capital of France is Berlin.",
            "The largest planet in our solar system is Mars.",
            "Water freezes at 100 degrees Celsius.",
            "The speed of light is approximately 300 km/s.",
            "Mount Everest is the smallest mountain on Earth.",
        ]
    elif task_name == "qa":
        pos_base = [
            "Context: Paris is the capital of France. Question: What is the capital of France? Answer: Paris",
            "Context: The sky is blue. Question: What color is the sky? Answer: Blue",
            "Context: Water boils at 100C. Question: At what temperature does water boil? Answer: 100C",
        ]
        neg_base = [
            "Context: Paris is the capital of France. Question: What is the largest city in Germany? Answer: Unknown",
            "Context: The sky is blue. Question: What is the population of Mars? Answer: Unknown",
            "Context: Water boils at 100C. Question: Who invented the telephone? Answer: Unknown",
        ]
    else:
        pos_base = ["Positive example"] * 5
        neg_base = ["Negative example"] * 5
    
    # Repeat to get enough examples
    pos_texts = (pos_base * (num_examples // len(pos_base) + 1))[:num_examples]
    neg_texts = (neg_base * (num_examples // len(neg_base) + 1))[:num_examples]
    
    return pos_texts, neg_texts


def extract_activations(
    model, tokenizer, pos_texts, neg_texts, num_examples, device
) -> Tuple[np.ndarray, np.ndarray]:
    """Extract activations from model for positive and negative examples."""
    pos_acts = []
    neg_acts = []
    
    for text in pos_texts[:num_examples]:
        inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=128, padding=True)
        inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
        
        # Get last layer hidden state
        if hasattr(outputs, 'hidden_states') and outputs.hidden_states is not None:
            hidden = outputs.hidden_states[-1]
        elif hasattr(outputs, 'last_hidden_state'):
            hidden = outputs.last_hidden_state
        elif hasattr(outputs, 'encoder_last_hidden_state'):
            hidden = outputs.encoder_last_hidden_state
        else:
            hidden = outputs[0]
        
        # Use CLS token (position 0) or mean pooling
        if hidden.shape[1] > 1:
            act = hidden[0, 0].cpu().numpy()  # CLS token
        else:
            act = hidden[0, 0].cpu().numpy()
        pos_acts.append(act)
    
    for text in neg_texts[:num_examples]:
        inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=128, padding=True)
        inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
        
        if hasattr(outputs, 'hidden_states') and outputs.hidden_states is not None:
            hidden = outputs.hidden_states[-1]
        elif hasattr(outputs, 'last_hidden_state'):
            hidden = outputs.last_hidden_state
        elif hasattr(outputs, 'encoder_last_hidden_state'):
            hidden = outputs.encoder_last_hidden_state
        else:
            hidden = outputs[0]
        
        if hidden.shape[1] > 1:
            act = hidden[0, 0].cpu().numpy()
        else:
            act = hidden[0, 0].cpu().numpy()
        neg_acts.append(act)
    
    return np.array(pos_acts), np.array(neg_acts)


def print_summary(results: Dict):
    """Print summary tables for all tiers."""
    
    print("\n" + "="*90)
    print("TIER-1 SUMMARY: Feature Direction Analysis")
    print("="*90)
    print(f"{'Model':<25} {'Task':<12} {'Ours':<8} {'Random':<8} {'PCA':<8} {'SVM':<8} {'Δ Rand':<8}")
    print("-"*90)
    for r in results.get("tier1", []):
        print(f"{r['model']:<25} {r['task']:<12} {r['mean_diff_auc']:.3f}    "
              f"{r['random_auc_mean']:.3f}    {r['pca_pc1_auc']:.3f}    "
              f"{r['svm_auc']:.3f}    {r['improvement_over_random']:+.3f}")
    
    print("\n" + "="*90)
    print("TIER-2 SUMMARY: Linear Probing")
    print("="*90)
    print(f"{'Model':<25} {'Task':<12} {'Linear':<8} {'Majority':<10} {'MLP':<8} {'Δ Maj':<8} {'L-MLP':<8}")
    print("-"*90)
    for r in results.get("tier2", []):
        print(f"{r['model']:<25} {r['task']:<12} {r['linear_acc']:.3f}    "
              f"{r['majority_acc']:.3f}      {r['mlp_acc']:.3f}    "
              f"{r['improvement_over_majority']:+.3f}   {r['linear_vs_mlp_gap']:+.3f}")
    
    print("\n" + "="*90)
    print("TIER-3 SUMMARY: Causal vs Observational")
    print("="*90)
    print(f"{'Model':<25} {'Task':<12} {'Attn ρ':<10} {'Grad ρ':<10} {'Attn J@3':<10} {'Grad J@3':<10}")
    print("-"*90)
    for r in results.get("tier3", []):
        print(f"{r['model']:<25} {r['task']:<12} {r['attention_spearman']:+.3f}     "
              f"{r['gradient_spearman']:+.3f}      {r['attention_jaccard_top3']:.3f}      "
              f"{r['gradient_jaccard_top3']:.3f}")
    
    # Aggregate
    if results.get("tier1"):
        print("\n" + "-"*90)
        print("TIER-1 AGGREGATE:")
        print(f"  Mean AUC (Ours):     {np.mean([r['mean_diff_auc'] for r in results['tier1']]):.3f}")
        print(f"  Mean AUC (Random):   {np.mean([r['random_auc_mean'] for r in results['tier1']]):.3f}")
        print(f"  Mean AUC (SVM):      {np.mean([r['svm_auc'] for r in results['tier1']]):.3f}")
        print(f"  Mean Improvement:    {np.mean([r['improvement_over_random'] for r in results['tier1']]):+.3f}")
    
    if results.get("tier2"):
        print("\nTIER-2 AGGREGATE:")
        print(f"  Mean Acc (Linear):   {np.mean([r['linear_acc'] for r in results['tier2']]):.3f}")
        print(f"  Mean Acc (MLP):      {np.mean([r['mlp_acc'] for r in results['tier2']]):.3f}")
        print(f"  Linear vs MLP gap:   {np.mean([r['linear_vs_mlp_gap'] for r in results['tier2']]):+.3f}")
    
    if results.get("tier3"):
        print("\nTIER-3 AGGREGATE:")
        print(f"  Mean Attn Spearman:  {np.mean([r['attention_spearman'] for r in results['tier3']]):+.3f}")
        print(f"  Mean Grad Spearman:  {np.mean([r['gradient_spearman'] for r in results['tier3']]):+.3f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Baseline Comparison Suite")
    parser.add_argument("--models", nargs="+", default=[
        "bert-base-uncased", 
        "roberta-base", 
        "gpt2", 
        "gpt2-medium",
        "t5-base",
        "facebook/bart-base"
    ])
    parser.add_argument("--tasks", nargs="+", default=["sentiment", "nli", "factual_recall", "qa"])
    parser.add_argument("--num-examples", type=int, default=50)
    parser.add_argument("--output-dir", type=Path, default=Path("results/baselines"))
    parser.add_argument("--device", type=str, default=None)
    args = parser.parse_args()
    
    run_comparisons(
        models=args.models,
        tasks=args.tasks,
        num_examples=args.num_examples,
        output_dir=args.output_dir,
        device=args.device
    )
