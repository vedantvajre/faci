#!/usr/bin/env python3
"""
Run individual tier analysis.

Usage:
    python scripts/run_tier.py --tier 1 --model bert-base-uncased --task sentiment
    python scripts/run_tier.py --tier 2 --model gpt2 --task nli
    python scripts/run_tier.py --tier 3 --model t5-base --task qa
"""

import argparse
import json
import logging
from pathlib import Path

import torch

from mechinterp import (
    MechanisticAnalyzer,
    set_seed,
    get_device,
    ExtractionPosition,
    PatchTarget,
)
from mechinterp.tasks import SentimentTask, NLITask, FactualRecallTask, QATask


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


TASKS = {
    "sentiment": SentimentTask,
    "nli": NLITask,
    "factual_recall": FactualRecallTask,
    "qa": QATask,
}


def run_tier1(
    analyzer,
    positive: list,
    negative: list,
    layer: int = -1,
    **kwargs
):
    """Run Tier 1 analysis."""
    logger.info("Running Tier 1: Feature Direction Analysis")
    
    # Set layer
    analyzer.tier1.layer = layer
    
    # Compute direction
    direction = analyzer.tier1.compute_feature_direction(positive, negative)
    logger.info(f"Direction shape: {direction.shape}")
    
    # Measure separation
    metrics = analyzer.tier1.measure_separation(positive, negative, direction)
    logger.info(f"Separation AUC: {metrics['auc']:.4f}")
    logger.info(f"Mean diff: {metrics['mean_difference']:.4f}")
    
    # Analyze across layers
    if kwargs.get("all_layers", False):
        logger.info("Analyzing across all layers...")
        layer_results = analyzer.tier1.analyze_across_layers(positive, negative)
        for l, result in sorted(layer_results.items()):
            logger.info(f"  Layer {l}: separation = {result.separation:.4f}")
    
    return {
        "direction_norm": torch.norm(direction).item(),
        "metrics": metrics,
    }


def run_tier2(
    analyzer,
    positive: list,
    negative: list,
    **kwargs
):
    """Run Tier 2 analysis."""
    logger.info("Running Tier 2: Linear Probing Analysis")
    
    # Prepare data
    texts = positive + negative
    labels = [1] * len(positive) + [0] * len(negative)
    
    # Probe all layers
    logger.info("Probing all layers...")
    layer_results = analyzer.tier2.probe_all_layers(texts, labels)
    
    # Log results
    for layer, metrics in sorted(layer_results.items()):
        logger.info(f"  Layer {layer}: accuracy = {metrics['accuracy']:.4f}")
    
    # Find key layers
    emergence = analyzer.tier2.find_emergence_layer(layer_results, threshold=0.6)
    best_layer, best_acc = analyzer.tier2.get_best_layer(layer_results)
    
    logger.info(f"Emergence layer (>60%): {emergence}")
    logger.info(f"Best layer: {best_layer} (accuracy = {best_acc:.4f})")
    
    return {
        "layer_accuracies": {l: m["accuracy"] for l, m in layer_results.items()},
        "emergence_layer": emergence,
        "best_layer": best_layer,
        "best_accuracy": best_acc,
    }


def run_tier3(
    analyzer,
    positive: list,
    negative: list,
    num_pairs: int = 5,
    **kwargs
):
    """Run Tier 3 analysis."""
    logger.info("Running Tier 3: Activation Patching Analysis")
    
    # Use multiple pairs for more robust results
    results = analyzer.tier3.analyze_with_multiple_examples(
        positive, negative, num_pairs=num_pairs
    )
    
    logger.info(f"Circuit size: {results.circuit_size} / {results.total_components}")
    logger.info(f"Sparsity: {results.sparsity:.4f}")
    
    # Show important components
    if results.important_components:
        logger.info(f"Important components: {results.important_components}")
    
    return {
        "circuit_size": results.circuit_size,
        "total_components": results.total_components,
        "sparsity": results.sparsity,
        "important_components": results.important_components,
        "component_effects": results.component_effects,
    }


def main():
    parser = argparse.ArgumentParser(description="Run individual tier analysis")
    
    parser.add_argument(
        "--tier", "-t",
        type=int,
        choices=[1, 2, 3],
        required=True,
        help="Which tier to run",
    )
    parser.add_argument(
        "--model", "-m",
        type=str,
        required=True,
        help="Model name",
    )
    parser.add_argument(
        "--task",
        type=str,
        choices=list(TASKS.keys()),
        required=True,
        help="Task name",
    )
    parser.add_argument(
        "--num-positive",
        type=int,
        default=100,
        help="Number of positive examples",
    )
    parser.add_argument(
        "--num-negative",
        type=int,
        default=100,
        help="Number of negative examples",
    )
    parser.add_argument(
        "--layer",
        type=int,
        default=-1,
        help="Layer to analyze (Tier 1)",
    )
    parser.add_argument(
        "--all-layers",
        action="store_true",
        help="Analyze all layers (Tier 1)",
    )
    parser.add_argument(
        "--num-pairs",
        type=int,
        default=5,
        help="Number of example pairs (Tier 3)",
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default=None,
        help="Output JSON file",
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Device (cuda, cpu, mps)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    
    args = parser.parse_args()
    
    # Set seed
    set_seed(args.seed)
    
    # Determine device
    device = args.device or str(get_device())
    logger.info(f"Using device: {device}")
    
    # Load task
    task = TASKS[args.task]()
    task.load_data(max_samples=max(args.num_positive, args.num_negative) * 3)
    
    positive = task.get_positive_examples(args.num_positive)
    negative = task.get_negative_examples(args.num_negative)
    
    logger.info(f"Loaded {len(positive)} positive, {len(negative)} negative examples")
    
    # Create analyzer
    analyzer = MechanisticAnalyzer(args.model, device=device)
    
    logger.info(f"Model: {args.model}")
    logger.info(f"Architecture: {analyzer.architecture.value}")
    logger.info(f"Layers: {analyzer.num_layers}")
    
    # Run specified tier
    if args.tier == 1:
        results = run_tier1(
            analyzer, positive, negative,
            layer=args.layer,
            all_layers=args.all_layers,
        )
    elif args.tier == 2:
        results = run_tier2(analyzer, positive, negative)
    elif args.tier == 3:
        results = run_tier3(
            analyzer, positive, negative,
            num_pairs=args.num_pairs,
        )
    
    # Save results
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"Results saved to {output_path}")


if __name__ == "__main__":
    main()
