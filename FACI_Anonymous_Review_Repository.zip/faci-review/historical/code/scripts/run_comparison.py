#!/usr/bin/env python3
"""
Compare mechanistic interpretability methods against baselines.

Usage:
    python scripts/run_comparison.py --model bert-base-uncased --task sentiment
"""

import argparse
import json
import logging
from pathlib import Path
from typing import Dict, List

import pandas as pd

from mechinterp import (
    MechanisticAnalyzer,
    set_seed,
    get_device,
)
from mechinterp.tiers import Tier1Analyzer, Tier2Analyzer, Tier3Analyzer
from mechinterp.baselines import (
    AttentionVisualization,
    AttentionRollout,
    GradientSaliency,
    IntegratedGradients,
    OcclusionSensitivity,
    LIMEExplainer,
)
from mechinterp.tasks import SentimentTask, NLITask, FactualRecallTask, QATask
from mechinterp.analysis import MethodComparison, save_results


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


TASKS = {
    "sentiment": SentimentTask,
    "nli": NLITask,
    "factual_recall": FactualRecallTask,
    "qa": QATask,
}


def run_comparison(
    model_name: str,
    task_name: str,
    num_examples: int = 50,
    output_dir: str = "results/comparisons",
    device: str = None,
) -> Dict:
    """
    Run full comparison of methods.
    """
    logger.info(f"Running comparison: {model_name} x {task_name}")
    
    # Load task
    task = TASKS[task_name]()
    task.load_data(max_samples=num_examples * 3)
    
    positive = task.get_positive_examples(num_examples)
    negative = task.get_negative_examples(num_examples)
    
    # Create analyzer
    analyzer = MechanisticAnalyzer(
        model_name=model_name,
        device=device,
        task="classification",
    )
    
    # Create tier analyzers
    tier1 = Tier1Analyzer(analyzer.model)
    tier2 = Tier2Analyzer(analyzer.model)
    tier3 = Tier3Analyzer(analyzer.model)
    
    # Create baselines
    baselines = [
        AttentionVisualization(analyzer.model),
        AttentionRollout(analyzer.model),
        GradientSaliency(analyzer.model),
        IntegratedGradients(analyzer.model, steps=20),
        OcclusionSensitivity(analyzer.model),
    ]
    
    # Skip LIME for speed (it's slow)
    # baselines.append(LIMEExplainer(analyzer.model, num_samples=100))
    
    # Run comparison
    comparison = MethodComparison(
        model=analyzer.model,
        tier1_analyzer=tier1,
        tier2_analyzer=tier2,
        tier3_analyzer=tier3,
        baselines=baselines,
    )
    
    result = comparison.run_comparison(
        positive_examples=positive,
        negative_examples=negative,
        task_name=task_name,
    )
    
    # Log results
    logger.info("=" * 60)
    logger.info("RESULTS SUMMARY")
    logger.info("=" * 60)
    
    for metric, value in result.comparison_metrics.items():
        logger.info(f"{metric}: {value:.4f}")
    
    # Save results
    output_path = Path(output_dir) / f"{model_name.replace('/', '_')}_{task_name}"
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Save metrics
    with open(output_path / "metrics.json", "w") as f:
        json.dump(result.comparison_metrics, f, indent=2)
    
    # Create comparison table
    comparison_table = create_comparison_table(result)
    comparison_table.to_csv(output_path / "comparison_table.csv", index=False)
    
    logger.info(f"Results saved to {output_path}")
    
    return result


def create_comparison_table(result) -> pd.DataFrame:
    """Create a comparison table of all methods."""
    rows = []
    
    # Tier methods
    if result.tier1_results:
        rows.append({
            "Method": "Tier 1 (Direction)",
            "Type": "Mechanistic",
            "Is Causal": "No",
            "Metric": f"Separation: {result.tier1_results.separation:.4f}",
        })
    
    if result.tier2_results:
        rows.append({
            "Method": "Tier 2 (Probing)",
            "Type": "Mechanistic",
            "Is Causal": "No",
            "Metric": f"Best Acc: {result.tier2_results.best_accuracy:.4f}",
        })
    
    if result.tier3_results:
        rows.append({
            "Method": "Tier 3 (Patching)",
            "Type": "Mechanistic",
            "Is Causal": "Yes",
            "Metric": f"Circuit: {result.tier3_results.circuit_size}/{result.tier3_results.total_components}",
        })
    
    # Baseline methods
    for name, data in result.baseline_results.items():
        rows.append({
            "Method": name.capitalize(),
            "Type": "Baseline",
            "Is Causal": "Yes" if data["is_causal"] else "No",
            "Metric": "Token importance",
        })
    
    return pd.DataFrame(rows)


def run_full_benchmark(
    models: List[str],
    tasks: List[str],
    **kwargs
):
    """Run comparison benchmark across models and tasks."""
    all_results = []
    
    for model in models:
        for task in tasks:
            try:
                result = run_comparison(model, task, **kwargs)
                all_results.append({
                    "model": model,
                    "task": task,
                    **result.comparison_metrics,
                })
            except Exception as e:
                logger.error(f"Failed {model} x {task}: {e}")
                continue
    
    # Create summary table
    if all_results:
        summary = pd.DataFrame(all_results)
        output_path = Path(kwargs.get("output_dir", "results/comparisons"))
        summary.to_csv(output_path / "benchmark_summary.csv", index=False)
        
        logger.info("\n" + "=" * 60)
        logger.info("BENCHMARK SUMMARY")
        logger.info("=" * 60)
        print(summary.to_string())
    
    return all_results


def main():
    parser = argparse.ArgumentParser(
        description="Compare mechanistic interpretability methods"
    )
    
    parser.add_argument(
        "--model", "-m",
        type=str,
        default="bert-base-uncased",
        help="Model name",
    )
    parser.add_argument(
        "--task", "-t",
        type=str,
        default="sentiment",
        choices=list(TASKS.keys()),
        help="Task name",
    )
    parser.add_argument(
        "--num-examples",
        type=int,
        default=50,
        help="Number of examples per class",
    )
    parser.add_argument(
        "--output-dir", "-o",
        type=str,
        default="results/comparisons",
        help="Output directory",
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Device",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    parser.add_argument(
        "--benchmark",
        action="store_true",
        help="Run full benchmark",
    )
    
    args = parser.parse_args()
    
    set_seed(args.seed)
    device = args.device or str(get_device())
    
    if args.benchmark:
        # Run full benchmark
        models = [
            "bert-base-uncased",
            "roberta-base",
            "gpt2",
        ]
        tasks = ["sentiment", "nli"]
        
        run_full_benchmark(
            models=models,
            tasks=tasks,
            num_examples=args.num_examples,
            output_dir=args.output_dir,
            device=device,
        )
    else:
        # Single run
        run_comparison(
            model_name=args.model,
            task_name=args.task,
            num_examples=args.num_examples,
            output_dir=args.output_dir,
            device=device,
        )


if __name__ == "__main__":
    main()
