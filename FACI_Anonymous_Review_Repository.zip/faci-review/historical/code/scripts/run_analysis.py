#!/usr/bin/env python3
"""
Run full mechanistic interpretability analysis.

Usage:
    python scripts/run_analysis.py --model bert-base-uncased --task sentiment
    python scripts/run_analysis.py --config configs/experiments/full_benchmark.yaml
"""

import argparse
import json
import logging
from pathlib import Path
from typing import List, Optional

import torch

from mechinterp import (
    MechanisticAnalyzer,
    set_seed,
    get_device,
    AnalysisResult,
)
from mechinterp.core import load_experiment_config
from mechinterp.tasks import SentimentTask, NLITask, FactualRecallTask, QATask
from mechinterp.analysis import save_results


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


# Task registry
TASKS = {
    "sentiment": SentimentTask,
    "nli": NLITask,
    "factual_recall": FactualRecallTask,
    "qa": QATask,
}


def run_single_analysis(
    model_name: str,
    task_name: str,
    num_positive: int = 100,
    num_negative: int = 100,
    tiers: List[int] = None,
    device: str = None,
    output_dir: str = "results",
) -> AnalysisResult:
    """
    Run analysis for a single model-task combination.
    """
    logger.info(f"Running analysis: {model_name} x {task_name}")
    
    # Load task
    if task_name not in TASKS:
        raise ValueError(f"Unknown task: {task_name}. Available: {list(TASKS.keys())}")
    
    task = TASKS[task_name]()
    task.load_data(max_samples=max(num_positive, num_negative) * 3)
    
    # Get examples
    positive = task.get_positive_examples(num_positive)
    negative = task.get_negative_examples(num_negative)
    
    logger.info(f"Loaded {len(positive)} positive, {len(negative)} negative examples")
    
    # Create analyzer
    analyzer = MechanisticAnalyzer(
        model_name=model_name,
        device=device,
        task="classification",
    )
    
    logger.info(f"Model architecture: {analyzer.architecture.value}")
    logger.info(f"Layers: {analyzer.num_layers}, Heads: {analyzer.num_heads}")
    
    # Run analysis
    results = analyzer.analyze(
        positive_texts=positive,
        negative_texts=negative,
        tiers=tiers or [1, 2, 3],
        task=task_name,
    )
    
    # Log results
    if results.tier1:
        logger.info(f"Tier 1 - Direction separation: {results.tier1.separation:.4f}")
    
    if results.tier2:
        logger.info(f"Tier 2 - Best layer: {results.tier2.best_layer}, "
                   f"Accuracy: {results.tier2.best_accuracy:.4f}")
        logger.info(f"Tier 2 - Emergence layer: {results.tier2.emergence_layer}")
    
    if results.tier3:
        logger.info(f"Tier 3 - Circuit size: {results.tier3.circuit_size}, "
                   f"Sparsity: {results.tier3.sparsity:.4f}")
    
    # Save results
    output_path = Path(output_dir) / f"{model_name.replace('/', '_')}_{task_name}"
    output_path.mkdir(parents=True, exist_ok=True)
    
    save_result(results, output_path / "results.json")
    logger.info(f"Results saved to {output_path}")
    
    return results


def save_result(result: AnalysisResult, path: Path):
    """Save analysis result to JSON."""
    data = {
        "model_name": result.model_name,
        "task_name": result.task_name,
        "architecture": result.architecture.value,
    }
    
    if result.tier1:
        data["tier1"] = {
            "separation": result.tier1.separation,
            "layer": result.tier1.layer,
            "position": result.tier1.position.value,
        }
    
    if result.tier2:
        data["tier2"] = {
            "best_accuracy": result.tier2.best_accuracy,
            "best_layer": result.tier2.best_layer,
            "emergence_layer": result.tier2.emergence_layer,
            "layer_accuracies": result.tier2.layer_accuracies,
        }
    
    if result.tier3:
        data["tier3"] = {
            "circuit_size": result.tier3.circuit_size,
            "total_components": result.tier3.total_components,
            "sparsity": result.tier3.sparsity,
            "component_effects": result.tier3.component_effects,
        }
    
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def run_benchmark(
    models: List[str],
    tasks: List[str],
    **kwargs
) -> List[AnalysisResult]:
    """Run benchmark across multiple models and tasks."""
    results = []
    
    for model in models:
        for task in tasks:
            try:
                result = run_single_analysis(model, task, **kwargs)
                results.append(result)
            except Exception as e:
                logger.error(f"Failed {model} x {task}: {e}")
                continue
    
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Run mechanistic interpretability analysis"
    )
    
    # Model/task selection
    parser.add_argument(
        "--model", "-m",
        type=str,
        help="Model name (HuggingFace or registered)",
    )
    parser.add_argument(
        "--task", "-t",
        type=str,
        choices=list(TASKS.keys()),
        help="Task name",
    )
    
    # Config file
    parser.add_argument(
        "--config", "-c",
        type=str,
        help="Path to experiment config YAML",
    )
    
    # Analysis options
    parser.add_argument(
        "--tiers",
        type=int,
        nargs="+",
        default=[1, 2, 3],
        help="Which tiers to run (1, 2, 3)",
    )
    parser.add_argument(
        "--num-positive",
        type=int,
        default=100,
        help="Number of positive examples",
    )
    parser.add_argument(
        "--num-negative",
        type=int,
        default=100,
        help="Number of negative examples",
    )
    
    # Output
    parser.add_argument(
        "--output-dir", "-o",
        type=str,
        default="results",
        help="Output directory",
    )
    
    # Device
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Device (cuda, cpu, mps)",
    )
    
    # Seed
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )
    
    args = parser.parse_args()
    
    # Set seed
    set_seed(args.seed)
    
    # Determine device
    device = args.device or str(get_device())
    logger.info(f"Using device: {device}")
    
    if args.config:
        # Load from config
        config = load_experiment_config(args.config)
        results = run_benchmark(
            models=config.models,
            tasks=config.tasks,
            tiers=config.tiers,
            num_positive=config.num_positive,
            num_negative=config.num_negative,
            output_dir=config.output_dir,
            device=device,
        )
    elif args.model and args.task:
        # Single run
        run_single_analysis(
            model_name=args.model,
            task_name=args.task,
            tiers=args.tiers,
            num_positive=args.num_positive,
            num_negative=args.num_negative,
            output_dir=args.output_dir,
            device=device,
        )
    else:
        parser.error("Must provide either --config or both --model and --task")


if __name__ == "__main__":
    main()
