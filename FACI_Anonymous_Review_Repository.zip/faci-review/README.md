# FACI — anonymous review artifacts

Code and recorded results for *When Is Activation Patching Well-Posed? Failure-Aware Causal Evaluation for Mechanistic Interpretability*.

## Start here

This snapshot includes the historical benchmark, the bounded BERT/RoBERTa NLI correction, and the token-site experiment. The directories identify these versions explicitly. The recorded measurements have not been rerun or changed for this release.

| Material | Location |
| --- | --- |
| Historical benchmark implementation, configurations, and archived results | `historical/` |
| Bounded NLI correction notebook | `notebooks/FACI_NLI_Correction_v1.ipynb` |
| Completed NLI correction: checks, per-seed outputs, summaries, source snapshot | `results/nli_correction/` |
| Token-site experiment notebook | `notebooks/FACI_Token_Sites_v1.ipynb` |
| Completed token-site experiment: cohort, raw measurements, checks, statistics | `results/token_sites/` |
| Paper's token-site figure and its plotting script | `figures/fig_token_sites.pdf`, `scripts/plot_token_sites.py` |
| Earlier exploratory precision notebook | `archive/precision_stability/` |

Read [reproduction instructions](docs/REPRODUCIBILITY.md) and the [artifact map](docs/ARTIFACT_MAP.md). The token-site results can be inspected and the paper figure replotted without model inference. Dependencies and hardware recorded during the completed runs are in each experiment's `environment.json`; notebook installation cells specify the corresponding packages.

## Version boundaries

The historical archive is retained as supplied, including its original README and verification notes. Those documents describe the earlier package; they are not a new validation of every historical result. The bounded correction concerns the recorded BERT/RoBERTa NLI conditions. It does not reconstruct missing historical pair-median layer profiles or establish the historical generative-scoring provenance. Files marked `candidate` or `Provisional` retain that status.

The separate token-site experiment compares read-out, edited-token, and unchanged-token patches on the same frozen cohort. It measures site-dependent recovery; it does not establish filtering reliability, the earliest depth of semantic computation, or a unique necessary representation. The exploratory precision notebook is included for completeness and is not evidence for a positive reliability claim.

## Inspecting the snapshot

`MANIFEST.sha256` records file hashes for this review snapshot. From the repository root, run `sha256sum -c MANIFEST.sha256` to check a local copy. An anonymizing host can rewrite matching text, so a host-modified file may no longer match its source hash.

Third-party attributions and dataset license notices are retained; see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). No model weights are included. Notebook outputs and interactive session metadata have been removed from review copies; all original code-cell text and recorded result files are preserved.
